import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.datatransfer.StringSelection;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class GUI{
		static JTextArea textArea;
	public GUI() {
		JFrame frame = new JFrame();
		textArea = new JTextArea(20,20);
		JButton runButton = new JButton("Remove JavaScript");
		JButton copyContent = new JButton("Copy");
		JPanel panel = new JPanel();
		
		GridBagConstraints c = new GridBagConstraints();
		
		runButton.addActionListener(new runApp());
		runButton.setBounds(10, 10, 10, 20);
		copyContent.addActionListener(new clipBoardCopy());
		copyContent.setBounds(10, 10, 10, 20);
		
		panel.setBorder(BorderFactory.createEmptyBorder(10, 10 , 10, 10));
		panel.setLayout(new GridBagLayout());
		panel.add(textArea, c);
		c.gridx = 1;
		c.gridy = 1;
		
		c.gridx = 0;
		c.gridy = 1;
		panel.add(runButton, c);
		c.gridx = 0;
		c.gridy = 2;
		panel.add(copyContent,c);
		
		frame.setResizable(true);
		frame.setLocationRelativeTo(null);
		frame.add(panel, BorderLayout.CENTER);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("JavaScript Remover");
		frame.pack();
		frame.setVisible(true);
	}

	public static void main(String[] args) {
		new GUI();
	}
}

class runApp implements ActionListener{
	
	public void actionPerformed(ActionEvent arg0) {
		
		RemoveScript run = new RemoveScript();
		String buff = GUI.textArea.getText();
		GUI.textArea.setText(run.removeScript(buff));

	}
}

class clipBoardCopy implements ActionListener{
	public void actionPerformed(ActionEvent arg0) {
		String copy = GUI.textArea.getText();
		StringSelection stringSelection = new StringSelection(copy);
		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		clipboard.setContents(stringSelection, null);
	}
}
