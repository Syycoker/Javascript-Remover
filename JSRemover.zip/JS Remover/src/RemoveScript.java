class RemoveScript {
	public String removeScript(String str) {
		String newStr = "";
		String startTag = "<script";
		String endTag = "</script>";
		int sLen = startTag.length();
		int eLen = endTag.length();
		
		boolean Tag = false;
		
		for(int i = 0; i < str.length(); i++) {
			if(i < str.length() - sLen) {
				if(str.substring(i, i + sLen).equals(startTag)) {
					Tag = true;
					i += sLen + 1;
				}
			}
			if(i < str.length() - eLen) {
				if(str.substring(i, i + eLen).equals(endTag)) {
					Tag = false;
					i += eLen + 1;
				}
			}
			if(Tag == false) {
				newStr += str.substring(i, i + 1);
			}
		}
		
		
		return newStr;
	}
}